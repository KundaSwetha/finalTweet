package com.tweetapp.configuration;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.tweetapp.util.TweetConstant;

import lombok.Generated;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Generated
@Service
public class KafkaConsumerConfig {

	@KafkaListener(topics = "message", groupId = TweetConstant.GROUP_ID)
	public void consume(String message) {
		log.info(String.format("Message received -> %s", message));
	}
}